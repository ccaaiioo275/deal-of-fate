
Deal of Fate - GitHub Pages package (Arcade cabinet style)

Files included:
- index.html : single-file HTML game (Phaser 3).
  * Arcade cabinet frame (640x480 window)
  * Cutscene intro, hub casino, bosses, save (localStorage)
  * Synth jazz loop via WebAudio, SFX, shop, dialogues
- README.txt : this file.

How to publish on GitHub Pages:
1) Create a new repository on GitHub.
2) Upload the content of this ZIP (index.html).
3) In Settings -> Pages, enable GitHub Pages for branch 'main' (or the branch you use) and set root directory.
4) Open the provided GitHub Pages URL. Click inside the game once to enable audio.
