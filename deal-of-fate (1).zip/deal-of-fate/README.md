# 🎰 Deal of Fate — Protótipo Completo

Um protótipo 2D estilo *Cuphead* + *Undertale*, feito em **HTML, CSS e JavaScript**, pronto para rodar no navegador.

## Conteúdo do pacote
- `index.html` — jogo completo (single-file). Não precisa de nada mais.
- `README.md` — instruções.

## Como usar
1. Baixe e extraia o arquivo `deal-of-fate.zip`.
2. Abra `index.html` no navegador (ou envie para um repositório GitHub e ative Pages).

## Publicar no GitHub Pages
1. Crie um repositório no GitHub (por exemplo `deal-of-fate`).
2. Adicione os arquivos (`index.html` e `README.md`) e faça push.
3. Vá em **Settings → Pages** e defina a branch principal (`main`) como source, root.
4. Acesse `https://SEU-USUARIO.github.io/deal-of-fate/`

## Controles
- **Mover:** `A` / `D` ou `←` / `→`
- **Pular:** `W` / `↑` / `Space`
- **Atirar:** `K`
- **Falar com NPCs:** Clique no lado direito da tela
- **Pausar/Reset/Mudo:** Botões no canto superior

## Recursos adicionados
- Tela de menu com botão Start animado
- Música de fundo e efeitos simples gerados via WebAudio (sem arquivos externos)
- Sistema de diálogo (typewriter + escolhas)
- Loja para comprar habilidades
- Bosses de exemplo: Dicey Don, Slotty Trio, Lady Spade, Mr. Stack

## Observações
- Este é um PROTÓTIPO: para um jogo completo, recomendo adicionar sprites, animações detalhadas, arte sonora e um motor (Phaser/Godot/Unity) caso queira mais funcionalidades.
- Desenvolvido por/para: **Caio Nascimento dos Santos**. Divirta-se!
